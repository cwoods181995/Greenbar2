"""Greenbar Lab helper. Loaded by the first cell of every notebook.

Works in the browser (JupyterLite / Pyodide) and in ordinary Python (setup_local).
Gives you: the card-program tables as pandas DataFrames, sql(), check(), hint(), solution(),
and a small Claude API helper (set_key, ask) for the AI track.
"""
import json, math, re, sys

ROOT = None
con = None
pd = None
np = None
_hint_pos = {}
LAST_USAGE = None
MODEL = "claude-haiku-4-5-20251001"   # change to any current model id, e.g. "claude-sonnet-5-5"
_KEY = None
IN_BROWSER = "pyodide" in sys.modules or sys.platform == "emscripten"
TABLES = ["departments", "employees", "cards", "merchants", "transactions", "expense_reports", "report_lines"]


# ------------------------------------------------------------------ loading
async def need(*packages):
    """Load Pyodide packages (no-op outside the browser)."""
    if not IN_BROWSER:
        return
    try:
        import pyodide_js
    except ImportError:
        return
    for p in packages:
        try:
            await pyodide_js.loadPackage(p)
        except Exception:
            pass


async def _fetch_text(root, path):
    if root:
        try:
            from pyodide.http import pyfetch
            r = await pyfetch(root + "/assets/" + path)
            if r.ok:
                return await r.string()
        except Exception:
            pass
    with open(path, encoding="utf-8") as f:   # fallback: copy in the file browser
        return f.read()


def _build(seed_sql):
    global con, pd, np
    import sqlite3
    import pandas
    import numpy
    pd, np = pandas, numpy
    con = sqlite3.connect(":memory:")
    con.executescript(seed_sql)
    g = globals()
    for t in TABLES:
        g[t] = pd.read_sql(f"SELECT * FROM {t}", con)
    g["txns"] = g["transactions"]
    g["__all__"] = TABLES + ["txns", "sql", "check", "hint", "solution", "show", "pd", "np", "con", "baseline_results"]
    _make_expected_cache()
    return {t: len(g[t]) for t in TABLES}


async def setup(root=None):
    """Called by each notebook's first cell."""
    global ROOT
    ROOT = root
    await need("pandas", "sqlite3")
    seed = await _fetch_text(root, "cardprogram.sql")
    counts = _build(seed)
    show("**Ready.** Tables loaded as DataFrames: " + ", ".join(f"`{t}` ({n:,})" for t, n in counts.items())
         + ". Also: `sql(\"…\")`, `check(\"id\", answer)`, `hint(\"id\")`, `solution(\"id\")`.")


def setup_local(path="cardprogram.sql"):
    """Use outside the browser: setup_local('path/to/cardprogram.sql')."""
    with open(path, encoding="utf-8") as f:
        return _build(f.read())


def sql(query, params=None):
    """Run SQL against the in-memory card-program database and return a DataFrame."""
    return pd.read_sql(query, con, params=params)


def show(md):
    try:
        from IPython.display import display, Markdown
        display(Markdown(md))
    except Exception:
        print(re.sub(r"[*`]", "", md))


# ------------------------------------------------------------------ exercises
# Each exercise: prompt (markdown), hints, solution (code that defines `answer`), kind, ordered, tests (funcs)
EX = {}
def ex(id, prompt, solution, hints, kind="df", ordered=False, tests=None, var="answer"):
    EX[id] = dict(id=id, prompt=prompt.strip(), solution=solution.strip(), hints=hints, kind=kind, ordered=ordered, tests=tests or [], var=var)

# --- py01 Python basics
ex("py01.1", "Given `amounts = [120.50, 89.99, 1045.00, 15.25]`, set `answer` to their total, rounded to 2 decimals.",
   "amounts = [120.50, 89.99, 1045.00, 15.25]\nanswer = round(sum(amounts), 2)",
   ["`sum()` adds up a list.", "`round(x, 2)` rounds to two decimals."], kind="value")
ex("py01.2", "Write a function `over_limit(card_type, amount)` that returns `True` when `amount` is greater than the limit for that card type in `limits = {'T&E': 5000, 'Purchasing': 10000, 'Meeting': 25000}`, otherwise `False`. Then check it with `check(\"py01.2\", over_limit)`.",
   "limits = {'T&E': 5000, 'Purchasing': 10000, 'Meeting': 25000}\ndef over_limit(card_type, amount):\n    return amount > limits[card_type]\nanswer = over_limit",
   ["Look up the limit with `limits[card_type]`.", "Return the comparison directly: `return amount > limits[card_type]`."], kind="func",
   tests=[("T&E", 6000), ("T&E", 5000), ("Purchasing", 9999.99), ("Meeting", 25000.01)])
ex("py01.3", "Given `raw = ['  atlas airways', 'HARBORVIEW HOTEL ', 'Atlas Airways Inc.']`, set `answer` to a new list where each name has surrounding spaces removed and is in Title Case.",
   "raw = ['  atlas airways', 'HARBORVIEW HOTEL ', 'Atlas Airways Inc.']\nanswer = [name.strip().title() for name in raw]",
   ["A list comprehension builds a new list: `[f(x) for x in items]`.", "Chain string methods: `name.strip().title()`."], kind="value")

# --- py02 DataFrames
ex("py02.1", "From `cards`, return `card_id`, `emp_id`, and `credit_limit` for Purchasing cards (`card_type == 'Purchasing'`).",
   "answer = cards.loc[cards['card_type'] == 'Purchasing', ['card_id', 'emp_id', 'credit_limit']]",
   ["Build a True/False mask: `cards['card_type'] == 'Purchasing'`.", "`df.loc[mask, [columns]]` filters rows and picks columns in one step."])
ex("py02.2", "From `transactions`, return `txn_id`, `card_id`, `amount_usd` for transactions over $1,000 whose `status` is `'Disputed'`.",
   "mask = (transactions['amount_usd'] > 1000) & (transactions['status'] == 'Disputed')\nanswer = transactions.loc[mask, ['txn_id', 'card_id', 'amount_usd']]",
   ["Combine masks with `&` (and) or `|` (or) — not the words `and`/`or`.", "Wrap each condition in parentheses: `(a > 1) & (b == 'x')`."])
ex("py02.3", "The 10 largest **Posted** transactions: `txn_id`, `merchant_id`, `amount_usd`, largest first.",
   "posted = transactions[transactions['status'] == 'Posted']\nanswer = posted.sort_values('amount_usd', ascending=False).head(10)[['txn_id', 'merchant_id', 'amount_usd']]",
   ["Filter first, then `sort_values('amount_usd', ascending=False)`.", "`.head(10)` keeps the first 10 rows."], ordered=True)

# --- py03 Grouping
ex("py03.1", "Count transactions by `status`: a DataFrame with columns `status` and `n`.",
   "answer = transactions.groupby('status').size().reset_index(name='n')",
   ["`groupby('status').size()` counts rows per group.", "`.reset_index(name='n')` turns the result back into a two-column DataFrame."])
ex("py03.2", "For **Posted** transactions, per `card_id`: `txn_count` and `total_usd` (rounded to 2 decimals).",
   "posted = transactions[transactions['status'] == 'Posted']\nanswer = (posted.groupby('card_id')\n          .agg(txn_count=('txn_id', 'count'), total_usd=('amount_usd', 'sum'))\n          .round({'total_usd': 2})\n          .reset_index())",
   ["Named aggregation: `.agg(new_name=('column', 'function'))`.", "Round one column with `.round({'total_usd': 2})`."])
ex("py03.3", "Count cards by `card_type` (rows) and `status` (columns), with 0 where there are none. Keep `card_type` as a column.",
   "answer = pd.crosstab(cards['card_type'], cards['status']).reset_index()",
   ["`pd.crosstab(rows, columns)` counts combinations.", "Or `cards.pivot_table(index='card_type', columns='status', values='card_id', aggfunc='count', fill_value=0)`."])

# --- py04 Merging
ex("py04.1", "Posted spend by merchant `category`: columns `category` and `total_usd` (rounded to 2 decimals).",
   "posted = transactions[transactions['status'] == 'Posted']\nm = posted.merge(merchants, on='merchant_id')\nanswer = m.groupby('category')['amount_usd'].sum().round(2).reset_index(name='total_usd')",
   ["`posted.merge(merchants, on='merchant_id')` is an inner join.", "Then group by `category` and sum `amount_usd`."])
ex("py04.2", "Cards that have **no** transactions at all: `card_id` and `card_type`.",
   "used = transactions['card_id'].unique()\nanswer = cards.loc[~cards['card_id'].isin(used), ['card_id', 'card_type']]",
   ["`series.isin(values)` tests membership; `~` negates it.", "Alternative: `cards.merge(transactions, how='left', indicator=True)` and keep `_merge == 'left_only'` (then drop duplicates)."])
ex("py04.3", "Each employee with a manager: `emp_id`, `employee` (first and last name with a space), and `manager` (the manager's name, same format). Leave out the employee with no manager.",
   "e = employees.assign(employee=employees['first_name'] + ' ' + employees['last_name'])\nmgr = e[['emp_id', 'employee']].rename(columns={'emp_id': 'manager_id', 'employee': 'manager'})\nanswer = e.merge(mgr, on='manager_id')[['emp_id', 'employee', 'manager']]",
   ["Build a full-name column first, then merge the table with a renamed copy of itself.", "Rename the copy's `emp_id` to `manager_id` so `on='manager_id'` lines up."])

# --- py05 Dates and cleaning
ex("py05.1", "Monthly **Posted** spend: `month` as text like `'2025-01'`, and `total_usd` (rounded to 2 decimals), in month order.",
   "posted = transactions[transactions['status'] == 'Posted'].copy()\nposted['month'] = pd.to_datetime(posted['txn_date']).dt.strftime('%Y-%m')\nanswer = posted.groupby('month')['amount_usd'].sum().round(2).reset_index(name='total_usd').sort_values('month')",
   ["`pd.to_datetime(col)` turns text into dates; `.dt.strftime('%Y-%m')` formats them.", "Group by the new `month` column; sort by it at the end."], ordered=True)
ex("py05.2", "Average days from `txn_date` to `post_date` for **Posted** transactions, rounded to 2 decimals (a single number).",
   "p = transactions[transactions['status'] == 'Posted']\ndays = (pd.to_datetime(p['post_date']) - pd.to_datetime(p['txn_date'])).dt.days\nanswer = round(days.mean(), 2)",
   ["Subtracting two date columns gives durations; `.dt.days` turns them into numbers.", "`.mean()` then `round(x, 2)`."], kind="value")
ex("py05.3", "Standardize `merchant_name`: strip spaces, upper-case, and remove a trailing `INC` or `INC.` (with any spaces before it). How many distinct standardized names are there? (a single number)",
   "clean = (merchants['merchant_name'].str.strip().str.upper()\n         .str.replace(r'\\s+INC\\.?$', '', regex=True).str.strip())\nanswer = clean.nunique()",
   ["`.str.strip().str.upper()` works on a whole column at once.", "Remove the suffix with `.str.replace(r'\\s+INC\\.?$', '', regex=True)`; count with `.nunique()`."], kind="value")

# --- py06 SQL from Python
ex("py06.1", "Use `sql()` to get declined transactions per card type: columns `card_type` and `declines`.",
   "answer = sql(\"\"\"\n    SELECT c.card_type, COUNT(*) AS declines\n    FROM transactions t JOIN cards c ON c.card_id = t.card_id\n    WHERE t.status = 'Declined'\n    GROUP BY c.card_type\n\"\"\")",
   ["Write the query as a triple-quoted string and pass it to `sql()`.", "Join `transactions` to `cards` on `card_id`, filter `t.status = 'Declined'`, group by `c.card_type`."])
ex("py06.2", "Write `spend_for(card_id)` that returns the card's total **Posted** spend (a float rounded to 2 decimals; 0.0 if none) using a **parameterized** query: `sql(query, params=(card_id,))` with a `?` placeholder.",
   "def spend_for(card_id):\n    df = sql(\"SELECT COALESCE(SUM(amount_usd), 0) AS s FROM transactions WHERE status = 'Posted' AND card_id = ?\", params=(card_id,))\n    return round(float(df['s'].iloc[0]), 2)\nanswer = spend_for",
   ["Put `?` where the value goes and pass `params=(card_id,)` — note the trailing comma.", "`COALESCE(SUM(...), 0)` returns 0 instead of NULL when nothing matches."], kind="func",
   tests=[(5003,), (5040,), (5101,), (9999,)])

# --- py07 Charts
ex("py07.1", "Prepare data for a chart: monthly **Posted** spend by card type — one row per `month` (`'YYYY-MM'`), one column per `card_type`, values rounded to 2 decimals, 0 where empty. Keep `month` as a column, in month order.",
   "p = transactions[transactions['status'] == 'Posted'].merge(cards[['card_id', 'card_type']], on='card_id')\np['month'] = pd.to_datetime(p['txn_date']).dt.strftime('%Y-%m')\nanswer = (p.pivot_table(index='month', columns='card_type', values='amount_usd', aggfunc='sum', fill_value=0)\n          .round(2).reset_index())\nanswer.columns.name = None",
   ["Merge in `card_type`, add a `month` column, then `pivot_table(index='month', columns='card_type', values='amount_usd', aggfunc='sum', fill_value=0)`.", "Finish with `.round(2).reset_index()`."], ordered=True)

# --- py08 Control testing in Python
ex("py08.1", "Write `over_single_limit(transactions, cards)` returning Posted transactions whose `amount_usd` exceeds the card's `single_txn_limit`: columns `txn_id`, `card_id`, `amount_usd`, `single_txn_limit`.",
   "def over_single_limit(transactions, cards):\n    t = transactions[transactions['status'] == 'Posted'].merge(cards[['card_id', 'single_txn_limit']], on='card_id')\n    return t.loc[t['amount_usd'] > t['single_txn_limit'], ['txn_id', 'card_id', 'amount_usd', 'single_txn_limit']]\nanswer = over_single_limit",
   ["Merge the limit onto each transaction, then filter where amount > limit.", "Return the four columns asked for."], kind="dffunc")
ex("py08.2", "Exact duplicates: Posted transactions that repeat an earlier one with the same `card_id`, `merchant_id`, `txn_date`, and `amount_usd`. Return the **later** copies only: `txn_id`, `card_id`, `amount_usd`.",
   "p = transactions[transactions['status'] == 'Posted'].sort_values('txn_id')\ndup = p.duplicated(subset=['card_id', 'merchant_id', 'txn_date', 'amount_usd'], keep='first')\nanswer = p.loc[dup, ['txn_id', 'card_id', 'amount_usd']]",
   ["`df.duplicated(subset=[...], keep='first')` marks every repeat after the first.", "Sort by `txn_id` first so 'first' means earliest."])

# --- ai03 Evaluation
ex("ai03.1", "With `results = baseline_results()` (columns `truth` and `predicted`), set `answer` to the share of rows where they match, as a percentage rounded to 1 decimal.",
   "answer = round((results['truth'] == results['predicted']).mean() * 100, 1)",
   ["`(a == b)` gives True/False per row; the mean of booleans is the share of True.", "Multiply by 100 and round to 1 decimal."], kind="value", var="answer")


def baseline_category(name, mcc):
    """A deliberately simple keyword classifier — the 'before AI' baseline for the AI track."""
    n = (name or "").lower()
    rules = [("air", "Airline"), ("hotel", "Lodging"), ("inn", "Lodging"), ("taxi", "Ground Transportation"),
             ("rideshare", "Ground Transportation"), ("rail", "Ground Transportation"), ("car rental", "Car Rental"),
             ("grill", "Restaurant"), ("cafe", "Restaurant"), ("bistro", "Restaurant"), ("kitchen", "Restaurant"),
             ("office", "Office Supplies"), ("casino", "Gambling"), ("cellar", "Liquor Store"), ("wireless", "Telecom")]
    for k, cat in rules:
        if k in n:
            return cat
    return "Other"


def baseline_results():
    """Merchants with the true category and the keyword baseline's guess."""
    return _results_frame()

def _results_frame():
    m = merchants.copy()
    m["predicted"] = [baseline_category(n, c) for n, c in zip(m["merchant_name"], m["mcc"])]
    return m.rename(columns={"category": "truth"})[["merchant_id", "merchant_name", "mcc", "truth", "predicted"]]


# ------------------------------------------------------------------ checking
_EXPECTED = {}
def _ns():
    g = globals()
    ns = {t: g[t].copy() for t in TABLES}
    ns.update(pd=pd, np=np, sql=sql, transactions=g["transactions"].copy())
    ns["txns"] = ns["transactions"]
    if "results" not in ns:
        ns["results"] = _results_frame()
    return ns

def _run_solution(e):
    ns = _ns()
    exec(e["solution"], ns)
    return ns[e["var"]]

def _make_expected_cache():
    _EXPECTED.clear()

def _expected(id):
    if id not in _EXPECTED:
        _EXPECTED[id] = _run_solution(EX[id])
    return _EXPECTED[id]

def _norm_df(x):
    if isinstance(x, pd.Series):
        x = x.reset_index() if (x.index.name is not None or isinstance(x.index, pd.MultiIndex)) else x.to_frame()
    if not isinstance(x, pd.DataFrame):
        return None
    if isinstance(x.index, pd.MultiIndex) or x.index.name is not None:
        x = x.reset_index()
    else:
        x = x.reset_index(drop=True)
    x = x.copy()
    x.columns = [str(c) for c in x.columns]
    return x

def _num(v):
    if v is None:
        return None
    try:
        if isinstance(v, (bool, np.bool_)):
            return None
        f = float(v)
        return None if math.isnan(f) else f
    except (TypeError, ValueError):
        return None

def _is_null(v):
    try:
        return v is None or (isinstance(v, float) and math.isnan(v)) or pd.isna(v) is True
    except Exception:
        return False

def _veq(a, b):
    if _is_null(a) or _is_null(b):
        return _is_null(a) and _is_null(b)
    if isinstance(a, (bool, np.bool_)) or isinstance(b, (bool, np.bool_)):
        return bool(a) == bool(b)
    na, nb = _num(a), _num(b)
    if na is not None and nb is not None:
        return abs(na - nb) <= 0.011 + 1e-9 * max(abs(na), abs(nb))
    return str(a) == str(b)

def _key(v):
    if _is_null(v):
        return "\0"
    n = _num(v)
    return "#%.1f" % n if n is not None else "s" + str(v)

def _rows(df):
    return [list(r) for r in df.itertuples(index=False, name=None)]

def _same_rows(ur, er, ordered):
    if len(ur) != len(er):
        return False
    if not ordered:
        ur = sorted(ur, key=lambda r: [_key(v) for v in r])
        er = sorted(er, key=lambda r: [_key(v) for v in r])
    return all(len(a) == len(b) and all(_veq(x, y) for x, y in zip(a, b)) for a, b in zip(ur, er))

def _compare_df(user, exp, ordered):
    u, e = _norm_df(user), _norm_df(exp)
    if u is None:
        return False, [f"Expected a DataFrame, got `{type(user).__name__}`."]
    msgs = []
    if u.shape[1] != e.shape[1]:
        extra = [c for c in u.columns if c not in e.columns]
        missing = [c for c in e.columns if c not in u.columns]
        msgs.append(f"Expected {e.shape[1]} columns ({', '.join('`'+c+'`' for c in e.columns)}), got {u.shape[1]}.")
        if missing: msgs.append("Missing by name: " + ", ".join("`"+c+"`" for c in missing) + ".")
        if extra: msgs.append("Not asked for: " + ", ".join("`"+c+"`" for c in extra) + ".")
        if "index" in u.columns: msgs.append("An `index` column appeared — use `.reset_index(drop=True)` to discard an old row index.")
        return False, msgs
    if len(u) != len(e):
        msgs.append(f"Expected {len(e):,} rows, got {len(u):,}.")
        msgs.append("Too many: check filters (and `&`/`|` with parentheses) or a merge that multiplies rows." if len(u) > len(e) else "Too few: a filter may be too strict, or an inner merge dropped rows.")
        return False, msgs
    # try matching columns by name first, then by position
    order = [list(u.columns).index(c) for c in e.columns] if set(u.columns) == set(e.columns) else list(range(u.shape[1]))
    ur = [[r[i] for i in order] for r in _rows(u)]
    er = _rows(e)
    if _same_rows(ur, er, ordered):
        notes = []
        if list(u.columns) != list(e.columns) and set(u.columns) != set(e.columns):
            notes.append("Column names differ from the exercise (" + ", ".join("`"+c+"`" for c in e.columns) + ") — fine here, but name them to match.")
        return True, notes
    if ordered and _same_rows(ur, er, False):
        return False, ["All the right rows, in the wrong order — check `sort_values` (column and `ascending=`)."]
    for i, (a, b) in enumerate(zip(sorted(ur, key=lambda r: [_key(v) for v in r]) if not ordered else ur,
                                   sorted(er, key=lambda r: [_key(v) for v in r]) if not ordered else er)):
        bad = [j for j, (x, y) in enumerate(zip(a, b)) if not _veq(x, y)]
        if bad:
            j = bad[0]
            return False, [f"Same shape, different values. First difference in column `{e.columns[j]}`: you have `{a[j]}`, expected `{b[j]}`."
                           + (" Check rounding." if _num(a[j]) is not None and _num(b[j]) is not None else "")]
    return False, ["Values differ from the expected result."]

def check(id, answer=None):
    """Check your answer: check("py02.1", answer)."""
    if id not in EX:
        return show(f"Unknown exercise id `{id}`.")
    e = EX[id]
    try:
        exp = _expected(id)
        if e["kind"] == "value":
            if isinstance(exp, (list, tuple)):
                ok = isinstance(answer, (list, tuple)) and len(answer) == len(exp) and all(_veq(a, b) for a, b in zip(answer, exp))
                msg = [] if ok else [f"Expected a list of {len(exp)} items like `{list(exp)[:3]}`; you have `{answer!r}`."[:400]]
            else:
                ok = _veq(answer, exp)
                msg = [] if ok else [f"Expected `{exp}`, you have `{answer!r}`."[:300]]
        elif e["kind"] == "func":
            if not callable(answer):
                return show(f"**Not yet** — pass the function itself: `check(\"{id}\", function_name)` (no parentheses).")
            ok, msg = True, []
            for args in e["tests"]:
                want = exp(*args)
                try:
                    got = answer(*args)
                except Exception as x:
                    ok = False; msg.append(f"`{args}` raised `{type(x).__name__}: {x}`."); break
                if not _veq(got, want):
                    ok = False; msg.append(f"For input `{args}` expected `{want}`, got `{got!r}`."); break
        elif e["kind"] == "dffunc":
            if not callable(answer):
                return show(f"**Not yet** — pass the function itself: `check(\"{id}\", function_name)`.")
            ns = _ns()
            ok, msg = _compare_df(answer(ns["transactions"], ns["cards"]), exp(ns["transactions"], ns["cards"]), e["ordered"])
        else:
            ok, msg = _compare_df(answer, exp, e["ordered"])
    except Exception as x:
        return show(f"**Error while checking:** `{type(x).__name__}: {x}`")
    if ok:
        show("**Correct.** " + " ".join(msg))
    else:
        show("**Not yet.** " + " ".join(msg) + f"  \nNeed a nudge? `hint(\"{id}\")`")

def hint(id):
    e = EX.get(id)
    if not e:
        return show(f"Unknown exercise id `{id}`.")
    i = _hint_pos.get(id, 0)
    if i >= len(e["hints"]):
        return show(f"No more hints. `solution(\"{id}\")` shows a worked answer.")
    _hint_pos[id] = i + 1
    show(f"**Hint {i + 1} of {len(e['hints'])}:** " + e["hints"][i])

def solution(id):
    e = EX.get(id)
    if e:
        show("```python\n" + e["solution"] + "\n```")


# ------------------------------------------------------------------ Claude API (bring your own key)
class ClaudeError(Exception):
    pass

def set_key(key):
    """Keep your API key in memory for this session only. Never save a notebook with the key in it."""
    global _KEY
    _KEY = (key or "").strip()
    show("Key set for this session" + (" (looks like an Anthropic key)." if _KEY.startswith("sk-ant-") else " — note: Anthropic keys usually start with `sk-ant-`."))

def _payload(prompt, system, model, max_tokens, messages):
    body = {"model": model or MODEL, "max_tokens": max_tokens,
            "messages": messages or [{"role": "user", "content": prompt}]}
    if system:
        body["system"] = system
    return body

def _parse(data):
    global LAST_USAGE
    if "error" in data:
        raise ClaudeError(data["error"].get("message", str(data["error"])))
    LAST_USAGE = data.get("usage")
    return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")

async def ask(prompt=None, system=None, model=None, max_tokens=800, messages=None):
    """Send one request to the Claude Messages API and return the text reply."""
    if not _KEY:
        raise ClaudeError("No API key set. Run gb.set_key('sk-ant-...') first (create a key in the Claude Console).")
    body = json.dumps(_payload(prompt, system, model, max_tokens, messages))
    headers = {"x-api-key": _KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"}
    if IN_BROWSER:
        from pyodide.http import pyfetch
        headers["anthropic-dangerous-direct-browser-access"] = "true"   # opt-in for calls made from a browser
        r = await pyfetch("https://api.anthropic.com/v1/messages", method="POST", headers=headers, body=body)
        return _parse(await r.json())
    import urllib.request, urllib.error
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=body.encode(), headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req) as resp:
            return _parse(json.loads(resp.read()))
    except urllib.error.HTTPError as x:
        return _parse(json.loads(x.read()))

def usage():
    """Token counts from the last call (what you're billed on)."""
    return LAST_USAGE
