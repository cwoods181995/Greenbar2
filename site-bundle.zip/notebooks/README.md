# Greenbar Lab notebooks

Open `00_start_here.ipynb` first. Each notebook's first cell loads the helper and data.
